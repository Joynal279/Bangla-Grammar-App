//
//  alertFile.swift
//  BanglaGrammer
//
//  Created by flow digital on 12/31/19.
//  Copyright © 2019 flow. All rights reserved.
//

import Foundation
class Alert {
    func alertfunction() {
//        let ob = QuizStart()
//        ob.alertAction()
    }
}
