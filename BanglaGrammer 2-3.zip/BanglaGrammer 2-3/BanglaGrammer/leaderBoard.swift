//
//  leaderBoard.swift
//  BanglaGrammer
//
//  Created by flow digital on 12/29/19.
//  Copyright © 2019 flow. All rights reserved.
//

import UIKit

class leaderBoard: UIViewController {
    let result = UserDefaults.standard.integer(forKey: "resultfinal")
    let question = UserDefaults.standard.integer(forKey: "questionfinal")
 
   
    @IBOutlet weak var correctlbl: UILabel!
    @IBOutlet weak var totalquestion: UILabel!
    @IBOutlet weak var resultlbl: UILabel!
    override func viewDidLoad() {
       resultlbl.text=String(result)
        totalquestion.text=String(question)
        correctlbl.text=String(result)
        print("point of the result : :\(result)")
        super.viewDidLoad()
        //resultlbl.text = res
        // Do any additional setup after loading the view.
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
